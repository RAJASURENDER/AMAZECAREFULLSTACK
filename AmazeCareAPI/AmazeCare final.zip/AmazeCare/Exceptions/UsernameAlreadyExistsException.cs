﻿namespace AmazeCare.Exceptions
{
    [Serializable]
    public class UsernameAlreadyExistsException : Exception
    {
        string message;
        public UsernameAlreadyExistsException()
        {
            message = "Username Already Exits, Try Another Username";
        }
        public override string Message => message;
    }
   
}
