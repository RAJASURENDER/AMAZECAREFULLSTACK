﻿namespace AmazeCare.Models.DTOs
{
    public class ResetPasswordDTO
    {
        public string? Username { get; set; }

        public string NewPassword { get; set; }
    }
}

